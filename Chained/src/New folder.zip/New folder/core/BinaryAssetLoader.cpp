#include "../headers/BinaryAssetLoader.h"
#include "../headers/SpriteAtlas.h"
#include "../headers/resourceManager.h"
#include <iostream>
#include <nlohmann/json.hpp>

namespace Chained {

bool BinaryAssetLoader::convertJsonToBinary(const std::string& jsonFile, const std::string& binaryFile) {
    std::cout << "[BINARY] Converting " << jsonFile << " to " << binaryFile << std::endl;
    
    // Read JSON file
    std::ifstream jsonStream(jsonFile);
    if (!jsonStream.is_open()) {
        std::cerr << "[ERROR] Could not open JSON file: " << jsonFile << std::endl;
        return false;
    }
    
    nlohmann::json j;
    jsonStream >> j;
    jsonStream.close();
    
    // Extract data from JSON
    auto meta = j["meta"];
    int atlasW = meta["size"]["w"];
    int atlasH = meta["size"]["h"];
    std::string imageFile = meta["image"];
    
    // Prepare header
    SpriteAtlasHeader header;
    header.magic = SPRITE_ATLAS_MAGIC;
    header.version = CURRENT_VERSION;
    header.textureWidth = static_cast<uint32_t>(atlasW);
    header.textureHeight = static_cast<uint32_t>(atlasH);
    header.spriteCount = static_cast<uint32_t>(j["frames"].size());
    header.sliceCount = static_cast<uint32_t>(meta["slices"].size());
    strncpy_s(header.textureName, imageFile.c_str(), sizeof(header.textureName) - 1);
    
    // Prepare sprite data
    std::vector<SpriteData> sprites;
    for (auto& [frameName, frameData] : j["frames"].items()) {
        auto frame = frameData["frame"];
        SpriteData sprite;
        strncpy_s(sprite.name, frameName.c_str(), sizeof(sprite.name) - 1);
        sprite.x = frame["x"] / float(atlasW);
        sprite.y = 1.0f - (float(frame["y"]) + float(frame["h"])) / float(atlasH);
        sprite.w = frame["w"] / float(atlasW);
        sprite.h = frame["h"] / float(atlasH);
        sprite.duration = frameData["duration"];
        sprites.push_back(sprite);
    }
    
    // Prepare slice data
    std::vector<SliceData> slices;
    for (auto& slice : meta["slices"]) {
        std::string name = slice["name"];
        if (name.empty()) continue;
        
        auto bounds = slice["keys"][0]["bounds"];
        SliceData sliceData;
        strncpy_s(sliceData.name, name.c_str(), sizeof(sliceData.name) - 1);
        sliceData.x = bounds["x"] / float(atlasW);
        sliceData.y = (atlasH - bounds["y"] - bounds["h"]) / float(atlasH); // Invert Y
        sliceData.w = bounds["w"] / float(atlasW);
        sliceData.h = bounds["h"] / float(atlasH);
        slices.push_back(sliceData);
    }
    
    // Write binary file
    std::ofstream binaryStream(binaryFile, std::ios::binary);
    if (!binaryStream.is_open()) {
        std::cerr << "[ERROR] Could not create binary file: " << binaryFile << std::endl;
        return false;
    }
    
    if (!writeHeader(binaryStream, header)) {
        std::cerr << "[ERROR] Failed to write header" << std::endl;
        return false;
    }
    
    if (!writeSpriteData(binaryStream, sprites)) {
        std::cerr << "[ERROR] Failed to write sprite data" << std::endl;
        return false;
    }
    
    if (!writeSliceData(binaryStream, slices)) {
        std::cerr << "[ERROR] Failed to write slice data" << std::endl;
        return false;
    }
    
    binaryStream.close();
    std::cout << "[BINARY] Successfully converted " << sprites.size() << " sprites and " << slices.size() << " slices" << std::endl;
    return true;
}

std::unique_ptr<SpriteAtlas> BinaryAssetLoader::loadSpriteAtlas(const std::string& binaryFile) {
    std::cout << "[BINARY] Loading sprite atlas from " << binaryFile << std::endl;
    
    std::ifstream file(binaryFile, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "[ERROR] Could not open binary file: " << binaryFile << std::endl;
        return nullptr;
    }
    
    // Read header
    SpriteAtlasHeader header;
    if (!readHeader(file, header)) {
        std::cerr << "[ERROR] Failed to read header" << std::endl;
        return nullptr;
    }
    
    // Validate header
    if (header.magic != SPRITE_ATLAS_MAGIC) {
        std::cerr << "[ERROR] Invalid magic number" << std::endl;
        return nullptr;
    }
    
    if (header.version != CURRENT_VERSION) {
        std::cerr << "[ERROR] Unsupported version: " << header.version << std::endl;
        return nullptr;
    }
    
    // Read sprite data
    std::vector<SpriteData> sprites;
    if (!readSpriteData(file, sprites, header.spriteCount)) {
        std::cerr << "[ERROR] Failed to read sprite data" << std::endl;
        return nullptr;
    }
    
    // Read slice data
    std::vector<SliceData> slices;
    if (!readSliceData(file, slices, header.sliceCount)) {
        std::cerr << "[ERROR] Failed to read slice data" << std::endl;
        return nullptr;
    }
    
    file.close();
    
    // Create SpriteAtlas
    auto atlas = std::make_unique<SpriteAtlas>();
    
    // Load texture
    atlas->m_texture = ResourceManager::get()->loadTexture(header.textureName, true, header.textureName);
    
    // Convert sprite data to frames
    for (const auto& sprite : sprites) {
        glm::vec4 uv(sprite.x, sprite.y, sprite.w, sprite.h);
        atlas->m_frames[sprite.name] = { uv, static_cast<int>(sprite.duration) };
    }
    
    // Convert slice data to slices
    for (const auto& slice : slices) {
        glm::vec4 uv(slice.x, slice.y, slice.w, slice.h);
        atlas->m_slices[slice.name] = { uv, 0 };
    }
    
    std::cout << "[BINARY] Successfully loaded " << sprites.size() << " sprites and " << slices.size() << " slices" << std::endl;
    return atlas;
}

bool BinaryAssetLoader::validateBinaryFile(const std::string& binaryFile) {
    std::ifstream file(binaryFile, std::ios::binary);
    if (!file.is_open()) {
        return false;
    }
    
    SpriteAtlasHeader header;
    if (!readHeader(file, header)) {
        return false;
    }
    
    file.close();
    
    return header.magic == SPRITE_ATLAS_MAGIC && header.version == CURRENT_VERSION;
}

bool BinaryAssetLoader::writeHeader(std::ofstream& file, const SpriteAtlasHeader& header) {
    file.write(reinterpret_cast<const char*>(&header), sizeof(header));
    return file.good();
}

bool BinaryAssetLoader::readHeader(std::ifstream& file, SpriteAtlasHeader& header) {
    file.read(reinterpret_cast<char*>(&header), sizeof(header));
    return file.good();
}

bool BinaryAssetLoader::writeSpriteData(std::ofstream& file, const std::vector<SpriteData>& sprites) {
    for (const auto& sprite : sprites) {
        file.write(reinterpret_cast<const char*>(&sprite), sizeof(sprite));
        if (!file.good()) return false;
    }
    return true;
}

bool BinaryAssetLoader::readSpriteData(std::ifstream& file, std::vector<SpriteData>& sprites, uint32_t count) {
    sprites.resize(count);
    for (auto& sprite : sprites) {
        file.read(reinterpret_cast<char*>(&sprite), sizeof(sprite));
        if (!file.good()) return false;
    }
    return true;
}

bool BinaryAssetLoader::writeSliceData(std::ofstream& file, const std::vector<SliceData>& slices) {
    for (const auto& slice : slices) {
        file.write(reinterpret_cast<const char*>(&slice), sizeof(slice));
        if (!file.good()) return false;
    }
    return true;
}

bool BinaryAssetLoader::readSliceData(std::ifstream& file, std::vector<SliceData>& slices, uint32_t count) {
    slices.resize(count);
    for (auto& slice : slices) {
        file.read(reinterpret_cast<char*>(&slice), sizeof(slice));
        if (!file.good()) return false;
    }
    return true;
}

} // namespace Chained 