// TestState.cpp
#include "../headers/TestState.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "../headers/RenderService.h"
#include <fstream>
#include <iostream>

using namespace Chained;
void TestState::onEnter() {
    // Try to load binary first, fall back to JSON if not available
    std::string binaryFile = "assets/textures/sprites.bin";
    std::string jsonFile = "assets/textures/sprites.json";
    
    // Check if binary file exists
    std::ifstream testFile(binaryFile);
    if (testFile.good()) {
        testFile.close();
        std::cout << "[TEST] Loading binary sprite atlas: " << binaryFile << std::endl;
        atlas = std::make_unique<SpriteAtlas>(binaryFile, true);
    } else {
        std::cout << "[TEST] Binary file not found, loading JSON: " << jsonFile << std::endl;
        atlas = std::make_unique<SpriteAtlas>(jsonFile);
    }
    
    renderer = std::shared_ptr<SpriteRenderer>(RenderService::getRenderer(), [](SpriteRenderer*) {});
}

void TestState::onExit() {}

void TestState::update(float) {
    // No logic yet
}

void TestState::render() {
    auto& heart = atlas->getSlice("heart");
    auto uv = heart.uvRect;
    uv.y = 1.0f - uv.y - uv.w;

    // Use a reasonable sprite size instead of scaling UV coordinates
    renderer->DrawSprite(
        atlas->getTexture(),
        glm::vec2(100, 100),
        glm::vec2(64, 64),  // Use a reasonable sprite size
        0.0f,
        glm::vec3(1.0f),
        uv
    );
    
}
