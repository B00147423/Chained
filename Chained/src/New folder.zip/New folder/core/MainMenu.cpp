﻿#include "../headers/MainMenu.h"
#include "../headers/resourceManager.h"
#include "../headers/TestState.h"
#include "../headers/Engine.h"
#include <GLFW/glfw3.h>
#include <glm/gtc/matrix_transform.hpp>

namespace Chained {

    MainMenu::MainMenu(Engine* eng) : engine(eng) {}

    void MainMenu::onEnter() {
        auto& rm = *ResourceManager::get();
        rm.addSearchPath("assets/shaders");
        rm.addSearchPath("assets/textures");

        auto shader = rm.loadShader("sprite.vert", "sprite.frag", nullptr, "sprite");
        renderer = std::make_shared<SpriteRenderer>(shader);

        glm::mat4 projection = glm::ortho(0.f, 800.f, 600.f, 0.f, -1.f, 1.f);
        shader->use();
        shader->setUniform("projection", projection);
        shader->setUniform("image", 0);

        atlas = std::make_unique<SpriteAtlas>("assets/textures/sprites.json");
    }

    void MainMenu::onExit() {}
    bool wasPressed = false;

    void MainMenu::update(float dt) {
        int windowWidth, windowHeight;
        glfwGetWindowSize(engine->getWindow(), &windowWidth, &windowHeight);

        double x, y;
        glfwGetCursorPos(engine->getWindow(), &x, &y);

        //  Convert to projection-space (800x600 logic)
        float projMouseX = (float)x * (800.0f / windowWidth);
        float projMouseY = (float)y * (600.0f / windowHeight);

        bool inside =
            projMouseX >= buttonPos.x && projMouseX <= buttonPos.x + buttonSize.x &&
            projMouseY >= buttonPos.y && projMouseY <= buttonPos.y + buttonSize.y;

        isHovered = inside;

        int state = glfwGetMouseButton(engine->getWindow(), GLFW_MOUSE_BUTTON_LEFT);
        if (isHovered && state == GLFW_PRESS) {
            isPressed = true;
        }

        if (isPressed && state == GLFW_RELEASE && isHovered) {
            isPressed = false;
            //  Play sound here if you have it
            engine->run(std::make_unique<TestState>());
        }

        if (state == GLFW_RELEASE) {
            isPressed = false;
        }

        // Animate button scale
        float targetScale = isPressed ? 0.95f : (isHovered ? 1.1f : 1.0f);
        clickScale += (targetScale - clickScale) * 10.0f * dt;
    }


    void MainMenu::render() {
        auto& playBtn = atlas->getSlice("play_button");
        auto uv = playBtn.uvRect;
        uv.y = 1.0f - uv.y - uv.w;

        // 🌀 Apply animated scale
        glm::vec2 scaledSize = buttonSize * clickScale;
        glm::vec2 offset = (buttonSize - scaledSize) * 0.5f;

        renderer->DrawSprite(
            atlas->getTexture(),
            buttonPos + offset,
            scaledSize,
            0.0f,
            glm::vec3(1.0f),
            uv
        );
    }

}
