#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <memory>
#include <fstream>
#include <iostream>
#include "Texture2D.h"
#include "types.h"

// Forward declaration
namespace Chained {
    class SpriteAtlas;
}

namespace Chained {

// Binary format magic numbers
constexpr uint32_t SPRITE_ATLAS_MAGIC = 0x53505254; // "SPRT"
constexpr uint32_t CURRENT_VERSION = 1;

// Binary file header
struct SpriteAtlasHeader {
    uint32_t magic;           // "SPRT" 
    uint32_t version;         // Format version
    uint32_t textureWidth;    // Atlas width
    uint32_t textureHeight;   // Atlas height
    uint32_t spriteCount;     // Number of sprites
    uint32_t sliceCount;      // Number of slices
    char textureName[256];    // Texture filename
};

// Binary sprite data
struct SpriteData {
    char name[64];           // Fixed-size name
    float x, y, w, h;        // UV coordinates
    uint32_t duration;       // Animation duration
};

// Binary slice data
struct SliceData {
    char name[64];           // Fixed-size name
    float x, y, w, h;        // UV coordinates
};

class BinaryAssetLoader {
public:
    // Convert JSON to binary format
    static bool convertJsonToBinary(const std::string& jsonFile, const std::string& binaryFile);
    
    // Load sprite atlas from binary file
    static std::unique_ptr<SpriteAtlas> loadSpriteAtlas(const std::string& binaryFile);
    
    // Validate binary file
    static bool validateBinaryFile(const std::string& binaryFile);

private:
    static bool writeHeader(std::ofstream& file, const SpriteAtlasHeader& header);
    static bool readHeader(std::ifstream& file, SpriteAtlasHeader& header);
    static bool writeSpriteData(std::ofstream& file, const std::vector<SpriteData>& sprites);
    static bool readSpriteData(std::ifstream& file, std::vector<SpriteData>& sprites, uint32_t count);
    static bool writeSliceData(std::ofstream& file, const std::vector<SliceData>& slices);
    static bool readSliceData(std::ifstream& file, std::vector<SliceData>& slices, uint32_t count);
};

} // namespace Chained 